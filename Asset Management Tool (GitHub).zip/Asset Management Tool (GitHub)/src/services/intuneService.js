// Intune device inventory: import the Intune "DevicesWithInventory" export, and serve the
// dashboard Device Compliance numbers, the Intune Devices list and its Excel export.
const ExcelJS = require('exceljs');
const db = require('../core/db');
const cache = require('../core/cache');
const audit = require('./auditService');
const Paginator = require('../core/paginator');
const { HttpError } = require('../core/helpers');

const STALE_DAYS = 30;
const REQUIRED = ['Device ID', 'Device name', 'Compliance'];
const COMPLIANCE_ORDER = ['Compliant', 'Noncompliant', 'InGracePeriod', 'ConfigManager', 'Not Evaluated'];
const PLATFORMS = ['Windows', 'macOS', 'iOS/iPadOS', 'Android', 'Other'];

const complianceLabel = v => (v ? String(v).replace(/([a-z])([A-Z])/g, '$1 $2') : 'Unknown');

function platformOf(os) {
  const s = String(os || '').toLowerCase();
  if (s.startsWith('windows')) return 'Windows';
  if (s.startsWith('mac')) return 'macOS';
  if (s.startsWith('ios') || s.startsWith('ipad')) return 'iOS/iPadOS';
  if (s.startsWith('android')) return 'Android';
  return 'Other';
}

function text(v) {
  if (v === null || v === undefined) return '';
  if (v instanceof Date) return Number.isNaN(v.getTime()) ? '' : v.toISOString();
  if (typeof v === 'object') {
    if (Array.isArray(v.richText)) return v.richText.map(r => r.text).join('');
    if ('result' in v) return text(v.result);
    if ('text' in v) return text(v.text);
    return '';
  }
  return String(v).trim();
}

// Intune writes "0001-01-01…" / "+010000-…" for "never"; treat anything outside 1990-2100 as empty.
function dateOf(v) {
  const d = v instanceof Date ? v : (text(v) ? new Date(text(v)) : null);
  if (!d || Number.isNaN(d.getTime())) return null;
  const y = d.getUTCFullYear();
  return y >= 1990 && y <= 2100 ? d : null;
}

function boolOf(v) {
  if (typeof v === 'boolean') return v;
  const s = text(v).toLowerCase();
  if (s === 'true' || s === 'yes') return true;
  if (s === 'false' || s === 'no') return false;
  return null;
}

function intOf(v) {
  const n = Number(text(v));
  return Number.isFinite(n) ? Math.round(n) : null;
}

async function parseWorkbook(buffer) {
  const wb = new ExcelJS.Workbook();
  try { await wb.xlsx.load(buffer); } catch (_) {
    throw new HttpError('Could not read this Excel file. Upload the Intune export as .xlsx.', 422);
  }
  const ws = wb.worksheets[0];
  if (!ws) throw new HttpError('The workbook has no sheets.', 422);
  const headers = [];
  ws.getRow(1).eachCell({ includeEmpty: true }, (c, col) => { headers[col] = text(c.value); });
  const col = name => headers.findIndex(h => h && h.toLowerCase() === name.toLowerCase());
  const missing = REQUIRED.filter(h => col(h) < 0);
  if (missing.length) {
    throw new HttpError(`This doesn't look like the Intune device export — missing column(s): ${missing.join(', ')}.`, 422);
  }
  const rows = [];
  const seen = new Set();
  ws.eachRow({ includeEmpty: false }, (row, n) => {
    if (n === 1) return;
    const get = name => { const i = col(name); return i < 0 ? null : row.getCell(i).value; };
    const deviceId = text(get('Device ID'));
    if (!deviceId || seen.has(deviceId)) return;
    seen.add(deviceId);
    const raw = {};
    headers.forEach((h, i) => { if (h) { const t = text(row.getCell(i).value); if (t) raw[h] = t; } });
    const os = text(get('OS'));
    rows.push({
      device_id: deviceId.slice(0, 64),
      device_name: text(get('Device name')).slice(0, 255) || null,
      serial_number: text(get('Serial number')).slice(0, 255) || null,
      manufacturer: text(get('Manufacturer')).slice(0, 255) || null,
      model: text(get('Model')).slice(0, 255) || null,
      os: os.slice(0, 100) || null,
      platform: platformOf(os),
      os_version: text(get('OS version')).slice(0, 100) || null,
      compliance: text(get('Compliance')).slice(0, 50) || null,
      managed_by: text(get('Managed by')).slice(0, 50) || null,
      ownership: text(get('Ownership')).slice(0, 50) || null,
      device_state: text(get('Device state')).slice(0, 50) || null,
      join_type: text(get('JoinType')).slice(0, 50) || null,
      encrypted: boolOf(get('Encrypted')),
      enrollment_date: dateOf(get('Enrollment date')),
      last_check_in: dateOf(get('Last check-in')),
      primary_user_upn: text(get('Primary user UPN')).slice(0, 255) || null,
      primary_user_email: text(get('Primary user email address')).slice(0, 255) || null,
      primary_user_name: text(get('Primary user display name')).slice(0, 255) || null,
      total_storage_mb: intOf(get('Total storage')),
      free_storage_mb: intOf(get('Free storage')),
      data: JSON.stringify(raw)
    });
  });
  if (!rows.length) throw new HttpError('No devices found in the file (no rows with a Device ID).', 422);
  return rows;
}

const COLS = ['device_id', 'device_name', 'serial_number', 'manufacturer', 'model', 'os', 'platform', 'os_version', 'compliance',
  'managed_by', 'ownership', 'device_state', 'join_type', 'encrypted', 'enrollment_date', 'last_check_in',
  'primary_user_upn', 'primary_user_email', 'primary_user_name', 'total_storage_mb', 'free_storage_mb', 'data'];

// The Intune export is a full snapshot, so an import replaces the previous one.
async function importWorkbook(buffer, fileName, user) {
  const rows = await parseWorkbook(buffer);
  const result = await db.tx(async t => {
    await t.run('DELETE FROM intune_devices');
    for (let s = 0; s < rows.length; s += 500) {
      const chunk = rows.slice(s, s + 500);
      const params = [];
      const values = chunk.map(r => '(' + COLS.map(c => { params.push(r[c]); return `$${params.length}${c === 'data' ? '::jsonb' : ''}`; }).join(', ') + ')');
      await t.run(`INSERT INTO intune_devices (${COLS.join(', ')}) VALUES ${values.join(', ')}`, params);
    }
    // Link each device to its Hardware record by serial number.
    const matched = await t.run(`UPDATE intune_devices d SET asset_id = a.id FROM assets a
      WHERE d.serial_number IS NOT NULL AND UPPER(a.serial_number) = UPPER(d.serial_number) AND a.deleted_at IS NULL`);
    await t.run('INSERT INTO intune_imports (file_name, rows_imported, matched_assets, imported_by) VALUES ($1, $2, $3, $4)',
      [String(fileName || '').slice(0, 255), rows.length, matched.rowCount, user ? user.id : null]);
    return { devices: rows.length, matched: matched.rowCount };
  });
  cache.del('hams_dashboard_metrics');
  await audit.log(user ? user.id : null, 'intune_import', `Imported Intune device data (${result.devices} devices, ${result.matched} linked to hardware) from ${fileName}`);
  return result;
}

async function lastImport() {
  return db.get(`SELECT i.*, u.name AS by_name FROM intune_imports i LEFT JOIN users u ON u.id = i.imported_by
    ORDER BY i.created_at DESC LIMIT 1`);
}

async function history(limit = 10) {
  return db.query(`SELECT i.*, u.name AS by_name FROM intune_imports i LEFT JOIN users u ON u.id = i.imported_by
    ORDER BY i.created_at DESC LIMIT $1`, [limit]);
}

const sortCompliance = list => list.sort((a, b) => {
  const ia = COMPLIANCE_ORDER.indexOf(a.value), ib = COMPLIANCE_ORDER.indexOf(b.value);
  return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || b.total - a.total;
});

// Dashboard numbers (cached with the rest of the dashboard).
async function summary() {
  const [totals, byCompliance, byPlatform, last] = await Promise.all([
    db.get(`SELECT COUNT(*)::int AS total,
        COUNT(*) FILTER (WHERE compliance = 'Compliant')::int AS compliant,
        COUNT(*) FILTER (WHERE compliance = 'Noncompliant')::int AS noncompliant,
        COUNT(*) FILTER (WHERE last_check_in IS NULL OR last_check_in < NOW() - INTERVAL '${STALE_DAYS} days')::int AS stale,
        COUNT(*) FILTER (WHERE encrypted = false)::int AS not_encrypted,
        COUNT(*) FILTER (WHERE asset_id IS NOT NULL)::int AS matched,
        COUNT(*) FILTER (WHERE asset_id IS NULL AND platform IN ('Windows', 'macOS'))::int AS unmatched_computers
      FROM intune_devices`),
    db.query('SELECT compliance AS value, COUNT(*)::int AS total FROM intune_devices GROUP BY 1'),
    db.query('SELECT platform, compliance AS value, COUNT(*)::int AS total FROM intune_devices GROUP BY 1, 2'),
    lastImport()
  ]);
  const compliance = sortCompliance(byCompliance).map(r => ({ value: r.value, label: complianceLabel(r.value), total: r.total }));
  const platforms = PLATFORMS.map(p => {
    const rows = byPlatform.filter(r => r.platform === p);
    const total = rows.reduce((n, r) => n + r.total, 0);
    const compliant = rows.filter(r => r.value === 'Compliant').reduce((n, r) => n + r.total, 0);
    return { platform: p, total, compliant, other: total - compliant };
  }).filter(p => p.total);
  return {
    ...totals,
    rate: totals.total ? Math.round(totals.compliant * 1000 / totals.total) / 10 : 0,
    compliance, platforms, stale_days: STALE_DAYS,
    last_import: last ? { at: last.created_at, file: last.file_name, by: last.by_name } : null
  };
}

// ─── Intune Devices list ───
function cleanFilters(q) {
  const s = (k, max = 100) => { const v = String(q[k] || '').trim(); return v && v.length <= max ? v : null; };
  return {
    search: s('search'),
    compliance: s('compliance', 50),
    platform: PLATFORMS.includes(String(q.platform)) ? String(q.platform) : null,
    ownership: s('ownership', 50),
    stale: q.stale === '1' ? '1' : null,
    encrypted: q.encrypted === '0' ? '0' : null,
    matched: q.matched === '0' || q.matched === '1' ? String(q.matched) : null,
    computers: q.computers === '1' ? '1' : null
  };
}

function describe(f) {
  const out = [];
  if (f.compliance) out.push(`Compliance: ${complianceLabel(f.compliance)}`);
  if (f.platform) out.push(`Platform: ${f.platform}`);
  if (f.computers) out.push('Computers (Windows / macOS)');
  if (f.ownership) out.push(`Ownership: ${f.ownership}`);
  if (f.stale) out.push(`No check-in for ${STALE_DAYS}+ days`);
  if (f.encrypted) out.push('Not encrypted');
  if (f.matched === '1') out.push('In Hardware register');
  if (f.matched === '0') out.push('Not in Hardware register');
  if (f.search) out.push(`Search: "${f.search}"`);
  return out;
}

function where(f, params) {
  const w = [];
  const add = (sql, v) => { params.push(v); w.push(sql.replace('?', '$' + params.length)); };
  if (f.search) {
    params.push(`%${f.search}%`);
    const p = '$' + params.length;
    w.push(`(d.device_name ILIKE ${p} OR d.serial_number ILIKE ${p} OR d.primary_user_name ILIKE ${p} OR d.primary_user_email ILIKE ${p} OR d.primary_user_upn ILIKE ${p} OR d.model ILIKE ${p})`);
  }
  if (f.compliance) add('d.compliance = ?', f.compliance);
  if (f.platform) add('d.platform = ?', f.platform);
  if (f.ownership) add('d.ownership = ?', f.ownership);
  if (f.computers) w.push(`d.platform IN ('Windows', 'macOS')`);
  if (f.stale) w.push(`(d.last_check_in IS NULL OR d.last_check_in < NOW() - INTERVAL '${STALE_DAYS} days')`);
  if (f.encrypted) w.push('d.encrypted = false');
  if (f.matched === '1') w.push('d.asset_id IS NOT NULL');
  if (f.matched === '0') w.push('d.asset_id IS NULL');
  return w.length ? 'WHERE ' + w.join(' AND ') : '';
}

const SELECT = `SELECT d.*, a.asset_tag, a.name AS asset_name,
    FLOOR(EXTRACT(EPOCH FROM (NOW() - d.last_check_in)) / 86400)::int AS days_since_check_in
  FROM intune_devices d LEFT JOIN assets a ON a.id = d.asset_id`;

async function page(pageNum, perPage, filters) {
  const params = [];
  const w = where(filters, params);
  const total = (await db.get(`SELECT COUNT(*)::int AS c FROM intune_devices d ${w}`, params)).c;
  const paginator = new Paginator(total, perPage, pageNum);
  const items = await db.query(`${SELECT} ${w} ORDER BY d.device_name ASC, d.id ASC LIMIT ${paginator.perPage} OFFSET ${paginator.offset}`, params);
  return { items, total, paginator };
}

async function exportRows(filters) {
  const params = [];
  return db.query(`${SELECT} ${where(filters, params)} ORDER BY d.device_name ASC, d.id ASC`, params);
}

const EXPORT_COLUMNS = [
  { header: 'Device name', key: 'device_name', width: 24 },
  { header: 'Serial number', key: 'serial_number', width: 18 },
  { header: 'Primary user', key: 'primary_user_name', width: 26 },
  { header: 'Primary user email', key: 'primary_user_email', width: 34 },
  { header: 'Compliance', key: 'compliance', width: 15 },
  { header: 'Platform', key: 'platform', width: 12 },
  { header: 'OS', key: 'os', width: 26 },
  { header: 'OS version', key: 'os_version', width: 16 },
  { header: 'Ownership', key: 'ownership', width: 12 },
  { header: 'Managed by', key: 'managed_by', width: 12 },
  { header: 'Join type', key: 'join_type', width: 20 },
  { header: 'Encrypted', key: 'encrypted', width: 10 },
  { header: 'Enrollment date', key: 'enrollment_date', width: 18, numFmt: 'dd-mmm-yyyy hh:mm' },
  { header: 'Last check-in', key: 'last_check_in', width: 18, numFmt: 'dd-mmm-yyyy hh:mm' },
  { header: 'Days since check-in', key: 'days_since_check_in', width: 12 },
  { header: 'Manufacturer', key: 'manufacturer', width: 16 },
  { header: 'Model', key: 'model', width: 22 },
  { header: 'Hardware asset tag', key: 'asset_tag', width: 16 },
  { header: 'Intune device ID', key: 'device_id', width: 38 }
];

async function filterOptions() {
  const [compliance, ownership] = await Promise.all([
    db.query('SELECT DISTINCT compliance AS v FROM intune_devices WHERE compliance IS NOT NULL'),
    db.query('SELECT DISTINCT ownership AS v FROM intune_devices WHERE ownership IS NOT NULL ORDER BY 1')
  ]);
  return {
    compliance: sortCompliance(compliance.map(r => ({ value: r.v, total: 0 }))).map(r => ({ value: r.value, label: complianceLabel(r.value) })),
    platforms: PLATFORMS,
    ownership: ownership.map(r => r.v)
  };
}

module.exports = {
  importWorkbook, summary, lastImport, history, page, exportRows, cleanFilters, describe, filterOptions,
  complianceLabel, EXPORT_COLUMNS, STALE_DAYS
};
