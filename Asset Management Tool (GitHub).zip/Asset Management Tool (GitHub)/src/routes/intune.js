// Intune Devices: list (dashboard Device Compliance drill-down), Excel export, and the
// Intune export upload on the Import Data page.
const express = require('express');
const multer = require('multer');
const intune = require('../services/intuneService');
const { authRequired, currentUser } = require('../middleware/auth');
const { csrfProtect } = require('../middleware/csrf');
const { perm, mod } = require('../middleware/permission');
const { hamsUrl, intOr } = require('../core/helpers');
const { sendWorkbook } = require('../core/excelExport');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 40 * 1024 * 1024 } });

function queryString(filters, extra = {}) {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries({ ...filters, ...extra })) if (v) qs.set(k, v);
  const s = qs.toString();
  return s ? '?' + s : '';
}

router.get('/intune-devices', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const filters = intune.cleanFilters(req.query);
    const fromDashboard = req.query.from === 'dashboard';
    const [result, options, last] = await Promise.all([
      intune.page(intOr(req.query.page, 1), 25, filters),
      intune.filterOptions(),
      intune.lastImport()
    ]);
    res.renderPage('intune/index', {
      devices: result.items, paginator: result.paginator, total: result.total,
      filters, options, last, fromDashboard, shownFilters: intune.describe(filters),
      staleDays: intune.STALE_DAYS, complianceLabel: intune.complianceLabel,
      baseUrl: hamsUrl('/intune-devices') + queryString(filters, { from: fromDashboard ? 'dashboard' : '' }),
      exportUrl: hamsUrl('/intune-devices/export') + queryString(filters)
    });
  } catch (err) { next(err); }
});

router.get('/intune-devices/export', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const filters = intune.cleanFilters(req.query);
    const rows = await intune.exportRows(filters);
    const name = filters.compliance ? 'Intune_' + intune.complianceLabel(filters.compliance) : 'Intune_Devices';
    await sendWorkbook(res, name + '_' + new Date().toISOString().slice(0, 10), [{ name: 'Intune devices', columns: intune.EXPORT_COLUMNS, rows }]);
  } catch (err) { next(err); }
});

// Import Data page: replace the Intune snapshot with a new "DevicesWithInventory" export.
router.post('/import-data/intune', authRequired, upload.single('file'), csrfProtect, perm('settings.manage'), mod('assets'), async (req, res, next) => {
  try {
    if (!req.file) { req.flash('error', 'Choose the Intune device export (.xlsx) to import.'); return res.redirect(hamsUrl('/import-data')); }
    if (!/\.xlsx$/i.test(req.file.originalname)) { req.flash('error', 'Upload the Intune device export as .xlsx.'); return res.redirect(hamsUrl('/import-data')); }
    try {
      const r = await intune.importWorkbook(req.file.buffer, req.file.originalname, await currentUser(req));
      req.flash('success', `Intune data imported: ${r.devices.toLocaleString('en-IN')} devices (${r.matched.toLocaleString('en-IN')} linked to Hardware by serial number). The dashboard Device Compliance section is updated.`);
    } catch (err) { req.flash('error', err.message); }
    res.redirect(hamsUrl('/import-data'));
  } catch (err) { next(err); }
});

module.exports = router;
