// Asset routes (port of AssetController + Dashboard + scan/label APIs + Procurement + Timeline + Catalog API).
const express = require('express');
const multer = require('multer');
const db = require('../core/db');
const authz = require('../services/authorizationService');
const assetService = require('../services/assetService');
const customFieldService = require('../services/customFieldService');
const platformService = require('../services/platformService');
const procurementService = require('../services/procurementService');
const timelineService = require('../services/timelineService');
const catalogService = require('../services/catalogService');
const { authRequired, currentUser } = require('../middleware/auth');
const { csrfProtect } = require('../middleware/csrf');
const { perm, mod } = require('../middleware/permission');
const { hamsUrl, sanitizeBody, intOr } = require('../core/helpers');
const { sendWorkbook } = require('../core/excelExport');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// ─── Dashboard ───
async function dashboardPage(req, res, next) {
  try {
    res.renderPage('home', { dashboard: await platformService.dashboard(), exportUrl: hamsUrl('/dashboard/export') });
  } catch (err) { next(err); }
}
router.get('/', authRequired, perm('dashboard.view'), dashboardPage);
router.get('/dashboard', authRequired, perm('dashboard.view'), dashboardPage);

// ─── Assets ───
// Hardware list filters from the query string (also used by the Excel export).
function assetFilters(req) {
  const search = String(req.query.search || '');
  const pick = (k, ok) => (ok(String(req.query[k] || '')) ? String(req.query[k]) : null);
  return {
    search,
    category_id: req.query.category_id || null,
    status_label_id: req.query.status_label_id || null,
    location_id: req.query.location_id || null,
    manufacturer_id: req.query.manufacturer_id || null,
    // Dashboard drill-downs
    assigned: pick('assigned', v => v === '0' || v === '1'),
    active: pick('active', v => v === '1'),
    warranty: pick('warranty', v => v === 'expiring'),
    repair: pick('repair', v => v === '1'),
    status_label: pick('status_label', v => v === 'none'),
    label_type: pick('label_type', v => ['deployable', 'deployed', 'pending', 'undeployable', 'archived'].includes(v)),
    created_month: pick('created_month', v => /^\d{4}-\d{2}$/.test(v)),
    category_name: pick('category_name', v => v.length > 0 && v.length <= 100),
    department: pick('department', v => v === 'none' || /^\d+$/.test(v)),
    compliance: pick('compliance', v => v.length > 0 && v.length <= 50)
  };
}

router.get('/assets', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const page = intOr(req.query.page, 1);
    const filters = assetFilters(req);
    const fromDashboard = req.query.from === 'dashboard';
    const result = await assetService.page(page, 15, filters, user);
    const references = await assetService.getReferenceData(user);
    // Keep every active filter on pagination links, not just the search text.
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(filters)) if (v) qs.set(k, v);
    if (fromDashboard) qs.set('from', 'dashboard');
    const baseUrl = hamsUrl('/assets') + (qs.toString() ? '?' + qs.toString() : '');
    // Human-readable description of the active filters (banner above the list).
    const nameOf = (list, id) => ((list || []).find(x => String(x.id) === String(id)) || {}).name;
    const shown = [];
    if (filters.status_label_id) shown.push(`Status: ${nameOf(references.status_labels, filters.status_label_id) || filters.status_label_id}`);
    if (filters.status_label) shown.push('Status: not set');
    if (filters.category_id) shown.push(`Category: ${nameOf(references.categories, filters.category_id) || filters.category_id}`);
    if (filters.category_name) shown.push(`Category: ${filters.category_name}`);
    if (filters.location_id) shown.push(`Location: ${nameOf(references.locations, filters.location_id) || filters.location_id}`);
    if (filters.manufacturer_id) shown.push(`Manufacturer: ${nameOf(references.manufacturers, filters.manufacturer_id) || filters.manufacturer_id}`);
    if (filters.assigned === '1') shown.push('Assigned to an employee');
    if (filters.assigned === '0') shown.push('Not assigned');
    if (filters.label_type === 'deployable') shown.push('In stock (deployable)');
    else if (filters.label_type) shown.push(`State: ${filters.label_type}`);
    if (filters.warranty) shown.push('Warranty expiring in 90 days');
    if (filters.repair) shown.push('In repair');
    if (filters.created_month) shown.push(`Added in ${filters.created_month}`);
    if (filters.department === 'none') shown.push('Department: unassigned');
    else if (filters.department) shown.push(`Department #${filters.department}`);
    if (filters.compliance) shown.push(`Intune compliance: ${filters.compliance === 'none' ? 'not enrolled in Intune' : filters.compliance}`);
    if (filters.active) shown.push('Active (not retired)');
    if (filters.search) shown.push(`Search: "${filters.search}"`);
    res.renderPage('assets/index', {
      assets: result.items, paginator: result.paginator, total: result.total,
      filters, references, baseUrl, fromDashboard, shownFilters: shown,
      // Header Excel icon: every asset matching the current filters, not just this page.
      exportUrl: hamsUrl('/assets/export') + (qs.toString() ? '?' + qs.toString() : ''),
      canAssign: await authz.can('assets.checkout', user),
      // Same rule as checkoutAsset and the in-stock picker.
      inStockCount: (await db.get(`SELECT COUNT(*)::int AS c FROM assets a LEFT JOIN status_labels sl ON a.status_label_id = sl.id
        WHERE a.deleted_at IS NULL AND a.assigned_to IS NULL
          AND LOWER(COALESCE(sl.name, a.status, '')) IN ('available', 'in stock', 'ready to deploy', 'ready')`)).c
    });
  } catch (err) { next(err); }
});

const ASSET_EXPORT_COLUMNS = [
  { header: 'Asset tag', key: 'asset_tag', width: 16 },
  { header: 'Name', key: 'name', width: 28 },
  { header: 'Serial number', key: 'serial_number', width: 18 },
  { header: 'Category', key: 'category_name', width: 16 },
  { header: 'Model', key: 'model_name', width: 24 },
  { header: 'Model number', key: 'model_number', width: 18 },
  { header: 'Manufacturer', key: 'manufacturer_name', width: 16 },
  { header: 'Status', key: 'status_label_name', width: 16 },
  { header: 'Location', key: 'location_name', width: 18 },
  { header: 'Assigned to', key: 'assigned_to_name', width: 26 },
  { header: 'Intune compliance', key: 'intune_compliance', width: 16 },
  { header: 'Supplier', key: 'supplier_name', width: 18 },
  { header: 'Purchase date', key: 'purchase_date', width: 14, numFmt: 'dd-mmm-yyyy' },
  { header: 'Purchase cost', key: 'purchase_cost', width: 14 },
  { header: 'Warranty expiry', key: 'warranty_expiry', width: 14, numFmt: 'dd-mmm-yyyy' },
  { header: 'Added on', key: 'created_at', width: 16, numFmt: 'dd-mmm-yyyy' }
];

router.get('/assets/export', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const scoped = await authz.applyLocationScope(assetFilters(req), user);
    const rows = (await assetService.exportRows(scoped)).map(a => ({
      ...a,
      category_name: a.category_name || a.category,
      status_label_name: a.status_label_name || a.status,
      purchase_cost: a.purchase_cost === null || a.purchase_cost === undefined ? null : Number(a.purchase_cost)
    }));
    await sendWorkbook(res, 'Hardware_' + new Date().toISOString().slice(0, 10), [{ name: 'Hardware', columns: ASSET_EXPORT_COLUMNS, rows }]);
  } catch (err) { next(err); }
});

// Dashboard as a workbook: one sheet per tile/chart, same numbers as on screen.
router.get('/dashboard/export', authRequired, perm('dashboard.view'), async (req, res, next) => {
  try {
    const d = await platformService.dashboard();
    const i = d.intune;
    const kv = [{ header: 'Metric', key: 'k', width: 36 }, { header: 'Value', key: 'v', width: 16 }];
    const lt = [{ header: 'Name', key: 'label', width: 30 }, { header: 'Assets', key: 'total', width: 12 }];
    const sheets = [
      { name: 'Summary', columns: kv, rows: [
        { k: 'Total assets', v: d.assets }, { k: 'Active users', v: d.users }, { k: 'Assigned assets', v: d.assigned },
        { k: 'In stock (deployable)', v: d.in_stock }, { k: 'In repair', v: d.repair },
        { k: 'Warranties expiring (90 days)', v: d.warranty_expiring }, { k: 'Serviceability index (%)', v: d.health }
      ] },
      { name: 'Acquisition by month', columns: [{ header: 'Month', key: 'month', width: 14 }, { header: 'New assets', key: 'total', width: 12 }], rows: d.trend },
      { name: 'By category', columns: lt, rows: d.by_category },
      { name: 'By department', columns: lt, rows: d.by_department },
      { name: 'Lifecycle states', columns: lt, rows: d.by_status },
      { name: 'Inventory stock', columns: [{ header: 'Module', key: 'm', width: 16 }, { header: 'Available', key: 'a', width: 12 }, { header: 'Total', key: 't', width: 12 }],
        rows: Object.entries(d.inventory_stock).map(([m, x]) => ({ m, a: x.available, t: x.total })) }
    ];
    if (i && i.total) {
      sheets.push(
        { name: 'Device compliance', columns: [{ header: 'Compliance state', key: 'label', width: 20 }, { header: 'Devices', key: 'total', width: 12 }, { header: '% of devices', key: 'pct', width: 12 }],
          rows: i.compliance.map(r => ({ ...r, pct: Math.round(r.total * 1000 / i.total) / 10 })) },
        { name: 'Compliance by platform', columns: [{ header: 'Platform', key: 'platform', width: 16 }, { header: 'Devices', key: 'total', width: 12 }, { header: 'Compliant', key: 'compliant', width: 12 }, { header: 'Not compliant', key: 'other', width: 14 }, { header: 'Compliance %', key: 'pct', width: 14 }],
          rows: i.platforms.map(p => ({ ...p, pct: Math.round(p.compliant * 1000 / p.total) / 10 })) },
        { name: 'Device risk', columns: kv, rows: [
          { k: 'Intune devices', v: i.total }, { k: 'Compliance rate (%)', v: i.rate }, { k: 'Noncompliant', v: i.noncompliant },
          { k: 'No check-in for ' + i.stale_days + '+ days', v: i.stale }, { k: 'Not encrypted', v: i.not_encrypted },
          { k: 'Linked to a Hardware record', v: i.matched }, { k: 'Computers not in Hardware register', v: i.unmatched_computers },
          { k: 'Intune data imported', v: i.last_import ? new Date(i.last_import.at) : null }
        ] }
      );
    }
    await sendWorkbook(res, 'Dashboard_' + new Date().toISOString().slice(0, 10), sheets);
  } catch (err) { next(err); }
});

router.get('/assets/create', authRequired, perm('assets.create'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    res.renderPage('assets/create', {
      references: await assetService.getReferenceData(user),
      asset_tag: await assetService.nextAssetTag()
    });
  } catch (err) { next(err); }
});

router.get('/assets/labels', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    let rawIds = req.query.ids || [];
    if (!Array.isArray(rawIds)) rawIds = String(rawIds).split(',');
    res.renderPage('assets/labels', { assets: await assetService.getLabelAssets(rawIds, user) });
  } catch (err) { next(err); }
});

router.get('/assets/scan', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    res.renderPage('assets/scan', { references: await assetService.getReferenceData(user) });
  } catch (err) { next(err); }
});

router.get('/labels/assets/:token', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const asset = await assetService.findByLabelToken(req.params.token);
    if (!asset) return res.renderPage('_error', { message: 'Asset label not found', statusCode: 404 });
    res.redirect(hamsUrl('/assets/' + asset.id));
  } catch (err) { next(err); }
});

router.get('/api/scan/:token', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const asset = await assetService.findByLabelToken(req.params.token);
    if (!asset) return res.status(404).json({ ok: false, message: 'Asset not found' });
    const status = String(asset.status_label_name || asset.status || '').toLowerCase();
    const isAvailable = ['available', 'ready to deploy', 'ready', 'in stock'].includes(status);
    const isAssigned = ['assigned', 'deployed', 'in use'].includes(status);
    res.json({
      ok: true,
      asset: {
        id: asset.id, name: asset.name, asset_tag: asset.asset_tag,
        serial: asset.serial_number,
        status: asset.status_label_name || asset.status,
        category: asset.category_name || asset.category
      },
      actions: { can_checkout: isAvailable, can_checkin: isAssigned },
      links: {
        view: hamsUrl('/assets/' + asset.id),
        checkout: hamsUrl('/assets/' + asset.id + '/checkout'),
        checkin: hamsUrl('/assets/' + asset.id + '/checkin')
      }
    });
  } catch (err) { next(err); }
});

router.post('/assets', authRequired, csrfProtect, perm('assets.create'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const data = sanitizeBody(req.body);
    try {
      if (await assetService.registerAsset(data, user)) {
        req.flash('success', 'Asset registered in enterprise ledger');
        return res.redirect(hamsUrl('/assets'));
      }
      req.flash('error', 'Registration failed');
    } catch (err) {
      req.flash('error', err.message);
    }
    res.redirect(hamsUrl('/assets/create'));
  } catch (err) { next(err); }
});

router.get('/api/categories/:id/fields', authRequired, mod('assets'), async (req, res, next) => {
  try {
    res.json(await customFieldService.getFieldsByCategory(intOr(req.params.id)));
  } catch (err) { next(err); }
});

router.get('/api/locations/:id/sub-locations', authRequired, mod('assets'), async (req, res, next) => {
  try {
    const rows = await db.query(
      'SELECT id, name, code, floor, room FROM sub_locations WHERE location_id = $1 AND deleted_at IS NULL ORDER BY name ASC',
      [intOr(req.params.id)]);
    res.json(rows);
  } catch (err) { next(err); }
});

router.post('/assets/bulk-delete', authRequired, csrfProtect, perm('assets.delete'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    let ids = req.body.ids || [];
    if (!Array.isArray(ids)) ids = [ids];
    ids = ids.map(Number).filter(Boolean);
    if (!ids.length) {
      req.flash('error', 'No assets selected.');
      return res.redirect(hamsUrl('/assets'));
    }
    const deleted = await assetService.bulkDeleteAssets(ids, user);
    req.flash('success', `${deleted} asset(s) deleted.`);
    res.redirect(hamsUrl('/assets'));
  } catch (err) { next(err); }
});

router.post('/assets/bulk-update', authRequired, csrfProtect, perm('assets.edit'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    let ids = req.body.ids || [];
    if (!Array.isArray(ids)) ids = [ids];
    ids = ids.map(Number).filter(Boolean);
    if (!ids.length) {
      req.flash('error', 'No assets selected.');
      return res.redirect(hamsUrl('/assets'));
    }
    const updateData = {};
    if (req.body.status_label_id) updateData.status_label_id = req.body.status_label_id;
    if (req.body.location_id) updateData.location_id = req.body.location_id;
    if (!Object.keys(updateData).length) {
      req.flash('error', 'No update fields provided.');
      return res.redirect(hamsUrl('/assets'));
    }
    try {
      const updated = await assetService.bulkUpdateAssets(ids, updateData, user);
      req.flash('success', `${updated} asset(s) updated successfully.`);
    } catch (err) {
      req.flash('error', err.message);
    }
    res.redirect(hamsUrl('/assets'));
  } catch (err) { next(err); }
});

router.get('/assets/:id', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const asset = await assetService.getAsset(intOr(req.params.id), user);
    if (!asset) return res.renderPage('_error', { message: 'Asset not found', statusCode: 404 });
    res.renderPage('assets/show', {
      asset,
      references: await assetService.getReferenceData(user),
      assignments: await assetService.assignmentHistory(asset.id),
      stock_history: await assetService.stockHistory(asset.id),
      custom_fields: await customFieldService.getFieldsByCategory(asset.category_id || 0),
      book_value: assetService.calculateDepreciation(asset)
    });
  } catch (err) { next(err); }
});

router.get('/assets/:id/edit', authRequired, perm('assets.edit'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const asset = await assetService.getAsset(intOr(req.params.id), user);
    if (!asset) return res.renderPage('_error', { message: 'Asset not found', statusCode: 404 });
    res.renderPage('assets/edit', { asset, references: await assetService.getReferenceData(user) });
  } catch (err) { next(err); }
});

router.post('/assets/:id/update', authRequired, csrfProtect, perm('assets.edit'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const id = intOr(req.params.id);
    try {
      if (await assetService.updateAsset(id, sanitizeBody(req.body), user)) {
        req.flash('success', 'Asset updated successfully');
        return res.redirect(hamsUrl('/assets/' + id));
      }
      req.flash('error', 'Asset update failed');
    } catch (err) {
      req.flash('error', err.message);
    }
    res.redirect(hamsUrl('/assets/' + id + '/edit'));
  } catch (err) { next(err); }
});

router.post('/assets/:id/delete', authRequired, csrfProtect, perm('assets.delete'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    if (await assetService.deleteAsset(intOr(req.params.id), user)) {
      req.flash('success', 'Asset deleted successfully');
    } else {
      req.flash('error', 'Asset delete failed');
    }
    res.redirect(hamsUrl('/assets'));
  } catch (err) { next(err); }
});

// Hardware page "Quick assign": pick an in-stock asset + a user. Same checkout
// logic as the asset page (availability re-checked, assignment, ledger, audit).
router.post('/assets/quick-assign', authRequired, csrfProtect, perm('assets.checkout'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const assetId = intOr(req.body.asset_id);
    const userId = intOr(req.body.user_id);
    try {
      if (!assetId) throw new Error('Choose an in-stock asset from the list.');
      if (!userId) throw new Error('Choose a user from the list.');
      const holder = await db.get('SELECT id, name, employee_id FROM users WHERE id = $1 AND deleted_at IS NULL', [userId]);
      if (!holder) throw new Error('That user no longer exists.');
      await assetService.checkoutAsset(assetId, {
        user_id: userId,
        checkout_notes: String(req.body.checkout_notes || '').trim().slice(0, 500) || 'Assigned from Hardware (quick assign)'
      }, user);
      const a = await db.get('SELECT asset_tag, name FROM assets WHERE id = $1', [assetId]);
      req.flash('success', `${a.name} (${a.asset_tag}) assigned to ${holder.name}${holder.employee_id ? ' (' + holder.employee_id + ')' : ''}.`);
    } catch (err) {
      req.flash('error', err.message);
    }
    res.redirect(hamsUrl('/assets'));
  } catch (err) { next(err); }
});

router.post('/assets/:id/checkout', authRequired, csrfProtect, perm('assets.checkout'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const id = intOr(req.params.id);
    try {
      await assetService.checkoutAsset(id, sanitizeBody(req.body), user);
      req.flash('success', 'Asset checked out successfully');
    } catch (err) {
      req.flash('error', err.message);
    }
    res.redirect(hamsUrl('/assets/' + id));
  } catch (err) { next(err); }
});

router.post('/assets/:id/checkin', authRequired, csrfProtect, perm('assets.checkout'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const id = intOr(req.params.id);
    try {
      await assetService.checkinAsset(id, sanitizeBody(req.body), user);
      req.flash('success', 'Asset checked in successfully');
    } catch (err) {
      req.flash('error', err.message);
    }
    res.redirect(hamsUrl('/assets/' + id));
  } catch (err) { next(err); }
});

// ─── Catalog API (inline creation) ───
router.get('/api/catalog/:type/search', authRequired, async (req, res) => {
  try {
    const results = await catalogService.search(req.params.type, String(req.query.q || '').trim());
    res.json({ ok: true, results });
  } catch (err) {
    res.status(400).json({ ok: false, message: err.message });
  }
});

router.post('/api/catalog/:type', authRequired, csrfProtect, perm('inventory.create'), async (req, res) => {
  try {
    const user = await currentUser(req);
    const data = sanitizeBody(req.body);
    const id = await catalogService.create(req.params.type, data, user);
    res.json({ ok: true, record: await catalogService.getCreatedRecord(req.params.type, id, data) });
  } catch (err) {
    res.status(422).json({ ok: false, message: err.message });
  }
});

// ─── Procurement ───
router.get('/procurement', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const search = String(req.query.search || '').trim();
    const result = await procurementService.getRecordsPage(intOr(req.query.page, 1), 25, search);
    res.renderPage('procurement/index', {
      records: result.records, paginator: result.paginator, total: result.total, search,
      baseUrl: hamsUrl('/procurement') + (search ? '?search=' + encodeURIComponent(search) : '')
    });
  } catch (err) { next(err); }
});

router.get('/procurement/create', authRequired, perm('assets.create'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    res.renderPage('procurement/create', { references: await assetService.getReferenceData(user) });
  } catch (err) { next(err); }
});

router.post('/procurement', authRequired,
  upload.fields([{ name: 'invoice', maxCount: 1 }, { name: 'po', maxCount: 1 }]), csrfProtect,
  perm('assets.create'), mod('assets'), async (req, res, next) => {
    try {
      const user = await currentUser(req);
      try {
        const id = await procurementService.createRecord(sanitizeBody(req.body), req.files, user);
        if (id) {
          req.flash('success', 'Procurement record created successfully');
          return res.redirect(hamsUrl('/procurement'));
        }
      } catch (err) {
        req.flash('error', err.message);
      }
      res.redirect(hamsUrl('/procurement/create'));
    } catch (err) { next(err); }
  });

router.get('/procurement/:id', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  try {
    const record = await procurementService.getRecord(intOr(req.params.id));
    if (!record) return res.renderPage('_error', { message: 'Record not found', statusCode: 404 });
    const assets = await procurementService.getLinkedAssets(record.id, { page: intOr(req.query.page, 1) });
    res.renderPage('procurement/show', {
      record, assets, paginator: assets.paginator, baseUrl: hamsUrl('/procurement/' + record.id)
    });
  } catch (err) { next(err); }
});

router.get('/procurement/:id/edit', authRequired, perm('assets.edit'), mod('assets'), async (req, res, next) => {
  try {
    const user = await currentUser(req);
    const record = await procurementService.getRecord(intOr(req.params.id));
    if (!record) return res.renderPage('_error', { message: 'Record not found', statusCode: 404 });
    res.renderPage('procurement/edit', { record, references: await assetService.getReferenceData(user) });
  } catch (err) { next(err); }
});

router.post('/procurement/:id/update', authRequired,
  upload.fields([{ name: 'invoice', maxCount: 1 }, { name: 'po', maxCount: 1 }]), csrfProtect,
  perm('assets.edit'), mod('assets'), async (req, res, next) => {
    try {
      const user = await currentUser(req);
      const id = intOr(req.params.id);
      try {
        if (await procurementService.updateRecord(id, sanitizeBody(req.body), req.files, user)) {
          req.flash('success', 'Procurement record updated successfully');
          return res.redirect(hamsUrl('/procurement/' + id));
        }
      } catch (err) {
        req.flash('error', err.message);
      }
      res.redirect(hamsUrl('/procurement/' + id + '/edit'));
    } catch (err) { next(err); }
  });

// ─── Internal APIs + Timeline ───
router.get('/api/dashboard', authRequired, perm('dashboard.view'), async (req, res, next) => {
  try { res.json(await platformService.dashboard()); } catch (err) { next(err); }
});

router.get('/api/assets', authRequired, perm('assets.view'), mod('assets'), async (req, res, next) => {
  // Same JSON-array response as before, but paged (?page=, ?per_page= up to 200) and
  // location-scoped; it used to return the first 1,000 full rows to any assets.view user.
  try {
    const user = await currentUser(req);
    const perPage = Math.min(Math.max(intOr(req.query.per_page, 100), 1), 200);
    const result = await assetService.page(intOr(req.query.page, 1), perPage, { search: String(req.query.search || '') }, user);
    res.setHeader('X-Total-Count', result.total);
    res.setHeader('X-Page', result.paginator.currentPage);
    res.setHeader('X-Per-Page', perPage);
    res.json(result.items);
  } catch (err) { next(err); }
});

router.get('/timeline/:module/:id', authRequired, perm('assets.view'), async (req, res, next) => {
  try {
    res.renderPage('timeline/show', {
      module: req.params.module,
      id: req.params.id,
      events: await timelineService.get(req.params.module, intOr(req.params.id))
    });
  } catch (err) { next(err); }
});

module.exports = router;
