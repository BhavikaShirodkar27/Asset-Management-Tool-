# IT-AMS v2 — bug-fix release

A copy of `IT-AMS-main` with the same screens, features and stack. Only bug fixes
were made. Every file not listed below is byte-for-byte identical to the original.

## Running it

| | Original | v2 |
|---|---|---|
| URL | http://localhost:3000 | http://localhost:3001 |
| Database | `it_hams` | `it_hams_v2` |
| Config | none (code defaults) | `.env` |

```bash
npm install
node bin/hams-cli.js migrate
node bin/hams-cli.js seed
npm start
```

Both apps can run at the same time. Login: `admin@hams.inc` / `password` (change it after first login).

## Security fixes

| Area | Problem | Fix | Files |
|---|---|---|---|
| MFA login | Someone with only the password could replace the victim's 2FA secret through `/login/mfa/setup` and log in | Enrolment only for users with no secret, and only with the secret the server generated | `routes/auth.js` |
| Data Transfer import | `filepath` came from the browser, so any server file could be read or deleted | Only files in the app's temp folder are accepted | `routes/platform.js` |
| Data Transfer users | Export included password hashes and 2FA secrets; import could set `role=super_admin` | Hidden credential columns; role/status/etc. can't be imported; imported users get a random password | `services/dataTransferService.js` |
| Role assignment | Users with "personnel.manage" could make themselves super admin (user edit, LDAP screen, CSV import) | One guard on every path: only super admins grant admin roles; the last super admin can't be demoted | `services/authorizationService.js`, `services/userService.js`, `services/importExportService.js`, `routes/admin.js` |
| Avatar upload | The browser-reported type was trusted, so an `.html` file could be uploaded and run scripts | File content is checked (PNG/JPG only); filename is generated | `routes/auth.js` |
| Procurement upload | HTML/SVG/JS files were served from the site | Those types are refused | `services/procurementService.js` |
| API tokens | A read-only token could create, edit or delete assets and configure monitors; every API call also created a browser login cookie | Each method and path needs its own permission; API calls don't create sessions | `middleware/apiToken.js`, `app.js` |
| Script injection (XSS) | Imported names were written raw into page scripts and `@click` attributes | Data in scripts is escaped (`safeJson`); attribute data is HTML-escaped | `core/helpers.js` + 12 views |
| CSRF | Agent key rotation, heartbeat config and alert resolve had no CSRF check | Token added | `routes/agents-ui.js`, `routes/heartbeat-ui.js`, 2 views |
| Barcode lookup / catalog API | Any employee could see cost, notes and assignee, or create catalog records | Full details only with `assets.view` (or for the asset's own holder); catalog create needs `inventory.create` | `routes/operations.js`, `routes/assets.js` |
| Location scope | Users limited to one site could edit, move or delete assets at other sites | Checked against the asset's current location for edit, delete, checkout, checkin and bulk actions | `services/assetService.js` |
| Password change | `min:8` compared numbers, so `"1234"` passed | `min_length:8` | `routes/auth.js` |
| Logout | Only `user_id` was cleared | The whole session is replaced | `routes/auth.js` |

## Functional fixes

| Problem | Fix | Files |
|---|---|---|
| "Select all" checkboxes did nothing (the JSON broke the HTML attribute) on Assets, Inventory, Stock, Departments and Catalog | Output is escaped correctly | views |
| Heartbeat detail page crashed (`last_check` doesn't exist), errors always showed "✓ OK", and Back/Cancel went to a 404 | Correct column names; links go to the asset | `views/heartbeat/detail.ejs` |
| Agent-reported machines were also pinged, so they flapped DOWN/UP and flooded alerts | Agents are excluded from probing; "agent" kept as a method | `services/heartbeat/heartbeatService.js` |
| Saving one SSO form (SAML) switched off LDAP and OIDC | Only the submitted form's checkboxes are reset | `views/settings/identity.ejs`, `routes/admin.js` |
| Saving backup settings went to a 404 | Redirects to `/settings/backups` | `routes/admin.js` |
| Database restore always failed | Backups use `--clean`; restore runs through `psql` | `services/backupService.js` |
| One bad row in a Data Transfer import silently rolled back the whole import | One savepoint per row | `services/dataTransferService.js` |
| Software import dropped columns (Sr., Ed/Ver, PO #, FAMS No., Market/Client/User Name), and the template's `Qty (0-10)` column was ignored | Header matching handles punctuation and hints; new columns stored | `services/softwareImportService.js` |
| Stock rollback could double-reverse, push stock negative, or undo stock for open assignments | Atomic delete-and-reverse; assignment movements refused | `services/stockMovementService.js` |
| Editing an inventory item could overwrite a concurrent assignment, or set the total below what is assigned | Available quantity computed in SQL; validation added | `services/inventoryService.js` |
| Approved or rejected requests could be reviewed again | Only pending requests can be reviewed | `services/requestService.js` |
| Two new joinees could be drafted the same laptop | Already-drafted laptops are excluded | `services/newJoineeService.js` |
| Asset timeline was sorted by weekday name and matched unrelated IDs (`#1` matched `#12`) | Sorted by date; whole-number ID match | `services/timelineService.js` |
| Re-enrolling an agent or adding an asset with an archived serial gave a raw error | Duplicate checks include archived rows; agents restore their old asset | `services/agentService.js`, `services/assetService.js`, `services/importExportService.js`, `services/userService.js` |
| Concurrent agent enrolments could clash on asset tags; the seed could too | Tag allocation is locked and skips used tags | `services/agentService.js`, `bin/hams-cli.js` |
| Simultaneous price saves gave a 500 | `ON CONFLICT` upsert | `services/licenseBudgetService.js` |
| GET `/login`, OIDC/SAML and LDAP actions could hang or crash the server on a DB error | Errors go to the error page | `routes/auth.js`, `routes/admin.js` |
| MFA and reset-password forms shared one rate-limit bucket per IP, locking out office users | Rate limits are per user/token and cleared on success | `middleware/rateLimit.js`, `routes/auth.js` |
| Asset list page 2 dropped the filters | All filters kept in pagination | `routes/assets.js` |
| Resolving an alert from a form returned raw JSON | JSON only for AJAX callers | `routes/heartbeat-ui.js` |
| `tools/import-synthetic.js` was hard-wired to port 3000 | Uses `APP_URL` from `.env` | `tools/import-synthetic.js` |

## Real asset data (Asset Data .csv)

The demo data was replaced with the company export using `tools/import-asset-data.js`.
Run it again whenever there is a newer export (it replaces the data each time):

```bash
node tools/import-asset-data.js "C:\Users\40211\OneDrive - CitiusTech\Asset Data .csv"
```

| Source column(s) | Where it goes in the app |
|---|---|
| Asset Type = Computing / Network / Servers | Hardware assets (16,735) |
| Asset Type = Accessories | Accessories module, one record per unit (8,903) |
| Employee Name, Email ID, CTID, Work Location | Users (7,136 employees; can't sign in until an admin sets a password) |
| Asset Status = Allocated | Assigned to that employee (8,964 hardware + 4,874 accessories) |
| Asset Location | Asset location (40 locations in total with Work Location) |
| Friendly Name / Manufacturer Name / Model Number / Vendor Name | Category / Manufacturer / Model / Supplier |
| PO #, Invoice No., Purchase Date, Amount | Procurement records (565 real POs), purchase date and cost |
| Warranty End Date | Warranty expiry |
| Remarks | Notes |
| Everything else (processor, RAM, OS, CTID, client, project, GRN, insured…) | Custom fields on the asset's page |

The 44 "Allocated" rows with `#N/A` as the email are stored as unassigned (the employee name is kept on the record).
The 26 duplicate service tags get a `-DUP` suffix (the original is kept on the record).
The database before the import was saved to `storage/backups/before-asset-data-import.sql`.

**Date fix found during this import:** every date showed one day early (for example 15-May-26 showed as
2026-05-14). The driver read dates as midnight India time and the pages formatted them in UTC.
Fixed in one place: `src/core/db.js`.

## Performance (after loading 25k real records)

The server answered in under 0.6 s, but the browser froze: the Users page was a 10 MB, 7,137-row page,
and every page generated its CSS in the browser and fetched its libraries from the internet.

| Change | Why | Files |
|---|---|---|
| Users and Procurement are paged (25 per page) and searchable in SQL | Users went from 10 MB and a 45+ s freeze to 78 KB and 0.8 s | `services/userService.js`, `services/procurementService.js`, `routes/admin.js`, `routes/assets.js`, 2 views |
| Type-to-search picker replaces every "all users / all assets / all items" dropdown | Lists of 7,000–16,000 options were heavy, and several were silently capped at the first 1,000, so most people/assets couldn't be picked | `routes/pickers.js`, `views/components/picker.ejs`, 7 views |
| Tailwind CSS built once (`npm run build:css` → `public/css/app.css`) instead of the in-browser Play CDN | The CDN script regenerated CSS on every page and re-scanned big tables | `tailwind.config.js`, `src/styles/tailwind.css`, layout + login pages |
| Alpine, Lucide and ApexCharts served locally at pinned versions | No internet fetch per click; versions can't change under you (`@latest`) | `app.js`, `package.json` |
| Icons drawn once per page instead of twice | `createIcons()` ran on both DOMContentLoaded and load | `views/layouts/main.ejs` |
| New Joinees only loads laptops/headsets for the joinees' locations | It shipped every in-stock laptop (828 KB) | `services/newJoineeService.js`, `routes/newJoinees.js` |
| Avatars drawn locally (initials SVG) instead of ui-avatars.com | Every page view sent employees' real names to a third-party site; also 25 extra requests per page | `core/helpers.js` (`avatarUrl`), 5 views, CSP |

If you edit a view and add new CSS classes, rebuild the stylesheet: `npm run build:css` (also runs automatically
with `npm start` and the VS Code "Run IT-HAMS" launch).

## Notes

- **Demo data:** this database is filled from synthetic generators (`tools/gen-synthetic.js`)
  and the sample pack. The original demo's own dataset files weren't in the project, so record counts differ.
- **Software sample file:** 476 of the 1,000 rows have a quantity of 100 or 500. The app correctly rejects
  them under its 0–10 rule, so 524 rows import. That is a data issue, not a code bug.
- **Tests:** `npm test` passes 10/10, all 54 pages return 200 after login, and the screens above were checked in a browser.

## New Joinee Excel import

New Joinees → **Import Excel** (needs the `assets.checkout` permission, the same one used by Allocate).

1. Upload `.xlsx` or `.csv` (template: **Download template** in the dialog; its "Valid values" sheet lists
   designations and every location with current laptop/headset stock).
2. Each row creates a pending directory account + new-joinee record. Re-importing updates joinees that are
   not yet allocated; a changed designation or location re-runs the recommendation.
3. Laptop + headset recommendations are drafted immediately (designation rules, joinee's location).
4. The engineer reviews/edits and clicks **Allocate**. That checks out the laptop, assigns the headset, activates
   the account, and writes the assignment, stock ledger and audit rows (visible in Hardware/Accessories).

| Column | Required | Notes |
|---|---|---|
| Employee ID (or CTID, Emp ID, Employee Code) | yes | unique; existing directory employees are skipped |
| Name | yes | |
| Designation | yes | Senior Director, AVP, Consultant, Engineer, Fresher (+ common aliases); others get the Engineer laptop |
| Location (or Work Location, Office) | yes | must match a location name exactly |
| Email | no | placeholder `<id>@pending-email.invalid` until provided |
| Employment Status | no | Employee (default) or Contractor |
| Date of Joining (or DOJ) | no | YYYY-MM-DD, DD-Mon-YYYY, DD/MM/YYYY or an Excel date; default today |

Files: `src/core/spreadsheet.js` (new), `src/services/newJoineeService.js`, `src/routes/newJoinees.js`,
`src/views/new-joinees/index.ejs`, `public/css/app.css` (rebuilt).

## Data replaced with "Asset Data.xlsx" (asset register + Intune)

Backup taken first: `storage/backups/before-asset-register-import-2026-10-04-12-57.sql`.
Loader: `tools/import-asset-register.js` (new; no application code or schema changed).

- Removed: all assets, accessories, assignments, stock ledger, procurement, catalog (models/manufacturers/suppliers/
  asset & accessory categories/locations), import history and employee accounts.
- Kept: admin account, roles, permissions, modules, settings, status labels, audit log, and the 17 New Joinees
  (re-recommended from the new stock).
- Loaded: 27,564 hardware assets + 15,018 accessories; 7,269 employees (CTID; name/email from the previous
  directory 6,745, Intune primary user 403, CTID only 121); 8,997 hardware + 6,813 accessory assignments;
  14,109 retired assets (Retired/Lost/Broken); 785 purchase orders.
- Skipped: 7,186 Intune-only rows (no Asset Type; mostly personal phones). Phone numbers and Wi-Fi IPs not imported.

## New Joinee allocation email + Location SPOCs

- **One Excel, two sheets**: New Joinees → Import Excel accepts a workbook with "New Joinee details" and
  "Location SPOC details" (found by sheet name, or by their columns). SPOC sheet columns: Location, SPOC Name,
  SPOC Email (required), Contact Number. Each location in the sheet has its SPOC list replaced. The template
  includes both sheets (SPOC sheet prefilled with saved SPOCs).
- **Allocation email**: after Allocate, the joinee gets an email (To) listing the laptop model, asset tag,
  serial, headphones (or "will be issued separately") and who to collect from. The location's SPOC(s) are in CC;
  if a location has no SPOC, the engineer who clicked Allocate is CC'd. Sent after the allocation is saved, so a mail
  problem never blocks or undoes an allocation. Every attempt is logged in `email_log` (sent/failed/skipped);
  the page shows the status with **Resend** for failed/skipped.
- **Laptop-only allocation**: Allocate needs a laptop; headphones are allocated when drafted, otherwise later.
- **SMTP**: configure Settings → Notifications (enable email, host, port, encryption, username, password, from),
  then **Send test**. The saved SMTP password is no longer echoed into the page; leave it blank to keep it.
  `SMTP_PASSWORD` in the environment overrides the stored password.
- Re-recommendation only runs when stock for a missing item exists at the joinee's location (no write on every
  page view while headphones are out of stock).
- Fixed: the Allocate confirmation broke for names with an apostrophe.

Files: `database/joinee_notifications.sql` (new: `location_spocs`, `email_log`), `bin/hams-cli.js`,
`src/services/mailService.js` (new), `src/core/spreadsheet.js`, `src/services/newJoineeService.js`,
`src/routes/newJoinees.js`, `src/views/new-joinees/index.ejs`, `src/routes/admin.js`,
`src/views/settings/notifications.ejs`, `package.json` (+ nodemailer 10), `public/css/app.css`.

## New Joinees: Remove

Each not-yet-allocated joinee has a **Remove** button (same permission as Allocate). It deletes the joinee record
and, when it is still the pending account created by the import and holds no assets, that directory account too,
so nothing about the person stays in the database (an audit entry records the removal). Allocated joinees can't be
removed; check their laptop in from Hardware first. Re-importing a file that still contains the person adds them again.
Files: `src/services/newJoineeService.js` (`removeJoinee`), `src/routes/newJoinees.js`, `src/views/new-joinees/index.ejs`.

## New Joinees: email preview

- **Preview** (allocated rows) and **Email** (drafts with a laptop) open the exact allocation email (To, CC with the
  location SPOC(s), subject, body) without sending anything, plus whether it would send now and why not
  (email disabled / SMTP not configured / no employee email).
- The CC fallback for locations without a SPOC is now the engineer who allocated (for allocated joinees) rather than
  whoever is viewing or resending.
Files: `src/services/newJoineeService.js` (`buildAllocationEmail`, `previewAllocationEmail`), `src/routes/newJoinees.js`,
`src/views/new-joinees/index.ejs`.

## Import Data (sync the Asset Data register)

New section **Asset Management → Import Data** (admins with `settings.manage`).
Upload the Asset Data workbook (.xlsx, same columns as before) → **preview** → **Apply changes**.

- Matched by **Service Tag** (duplicate tags by occurrence). Changed fields, status and allocation are updated;
  new assets, accessories, employees (by CTID), locations, categories, manufacturers, models, vendors and
  purchase orders are added. **Nothing is deleted**; records not in the file are left unchanged.
- Allocation changes are written like real check-outs/check-ins (assignment history + stock ledger).
- **Protected allocations**: an allocation or return made in the tool (New Joinee, check-out, check-in) is kept
  until a file shows the same thing (then the record is marked reconciled and the file is in charge again).
- Asset tags never change; Intune-only rows are skipped; runs in one transaction (all-or-nothing) in the
  background with progress; history of imports on the page.
- Verified: the same file again → 0 changes, 1 protected (Bhavika's laptop); a modified file → returns,
  assignments, reassignment to a new employee, retirement, field/location change and a new asset all applied
  correctly (inside a rolled-back transaction).

Files: `src/services/assetRegister.js` (reader), `src/services/assetRegisterSync.js` (preview/apply),
`src/routes/importData.js`, `src/views/import-data/index.ejs`, `src/app.js`, `src/views/layouts/main.ejs`.
The command-line full replace (`tools/import-asset-register.js`) is unchanged.

## Dashboard: device compliance + click-through

- **Device Compliance** (new): donut + breakdown of Intune compliance for active (not retired) hardware, from the
  Asset Data import (`Intune Compliance` detail): Compliant, Noncompliant, In Grace Period, Config Manager,
  Not Evaluated, Not enrolled in Intune; plus "% compliant of enrolled".
- **Everything is clickable**: KPI cards, Deployed/Stock/Repair, every bar/point/slice (acquisition month, category,
  department, lifecycle state, compliance, inventory stock) and audit entries open the matching filtered list.
  Lists opened from the dashboard show **← Back to Dashboard**, "Showing N assets — <filter>" and **Clear filter**.
  Counts on the dashboard equal the counts in the lists they open (verified for every link).
- "Stock" in System Resilience now means deployable stock (In Stock/Ready to Deploy), not total minus assigned
  (which counted 14k retired assets). The acquisition chart uses whole calendar months.
- New Hardware filters (also usable in URLs): `assigned`, `active`, `warranty=expiring`, `repair`, `label_type`,
  `status_label=none`, `created_month`, `category_name`, `department`, `compliance`.
Files: `src/services/platformService.js`, `src/services/assetService.js`, `src/routes/assets.js`,
`src/views/home.ejs`, `src/views/assets/index.ejs`, `src/middleware/viewLocals.js`, `src/views/layouts/main.ejs`.

## Hardware: Assign In-Stock Asset block
- New "Assign In-Stock Asset" block at the top of Hardware (shown to users with `assets.checkout`).
  Pick an in-stock asset and a user from type-to-search dropdowns, add optional notes, click Assign.
- Only unassigned assets with an in-stock status (Available / In Stock / Ready to Deploy) are offered
  (`/api/pick/instock-assets`). Assigning uses the same check-out as the asset page
  (`assetService.checkoutAsset`): status -> Deployed, assignment history, stock ledger and audit log.
- `POST /assets/quick-assign` (CSRF-protected) refuses missing users and already-assigned assets.
Files: `src/routes/pickers.js`, `src/routes/assets.js`, `src/views/assets/index.ejs`.

## Device Compliance from Intune data + Excel export icon
- New `intune_devices` table (migration `database/intune_devices.sql`), loaded from the Intune
  "DevicesWithInventory" export (13,909 devices). Devices are linked to Hardware by serial number.
  Upload a newer export on Import Data > "Intune Device Data"; each import replaces the previous snapshot
  (Hardware, users and allocations are not touched).
- Dashboard "Device Compliance" now uses this data: compliance donut, breakdown with %, compliance by
  platform, and tiles for Noncompliant, no check-in for 30+ days, not encrypted, linked to Hardware,
  computers not in the Hardware register. Every slice/row/bar/tile opens the new Intune Devices list
  (sidebar > Intune Devices) with Back to Dashboard.
- Green Excel icon at the top right of every page. Dashboard, Hardware, Intune Devices and Users download
  all records matching the current filter/drill-down; other pages download the tables shown on screen.
  Cells starting with = + - @ are written as text (no formula injection).
- Hardware export uses a narrow query (~1 s for 27k assets instead of ~10 s).
- Tailwind safelist: status-dot colours and hover borders built in templates.
Files: `database/intune_devices.sql`, `bin/hams-cli.js`, `src/services/intuneService.js`, `src/core/excelExport.js`,
`src/routes/intune.js`, `src/routes/exports.js`, `src/app.js`, `src/routes/assets.js`, `src/routes/admin.js`,
`src/routes/importData.js`, `src/services/platformService.js`, `src/services/assetService.js`,
`src/middleware/viewLocals.js`, `src/views/home.ejs`, `src/views/intune/index.ejs`,
`src/views/import-data/index.ejs`, `src/views/layouts/main.ejs`, `tailwind.config.js`, `public/css/app.css`.
