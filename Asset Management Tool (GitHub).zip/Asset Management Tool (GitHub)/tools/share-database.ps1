# Make a copy of your IT-AMS database to give to teammates (they load it with tools\restore-database.ps1).
# The file contains company data (employees, devices) - share it privately (OneDrive / Teams), NOT on GitHub.
# Usage (from the project folder):  powershell -ExecutionPolicy Bypass -File tools\share-database.ps1
param([string]$OutDir = (Join-Path (Split-Path $PSScriptRoot -Parent | Split-Path -Parent) 'IT-AMS-team-share'))

$ErrorActionPreference = 'Stop'
$envFile = Join-Path (Split-Path $PSScriptRoot -Parent) '.env'
$cfg = @{}
Get-Content $envFile | Where-Object { $_ -match '^\s*([A-Z_]+)\s*=\s*(.*)$' } | ForEach-Object { $cfg[$Matches[1]] = $Matches[2].Trim() }

$pgDump = Get-ChildItem 'C:\Program Files\PostgreSQL\*\bin\pg_dump.exe' -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1
if (-not $pgDump) { throw 'pg_dump.exe not found under C:\Program Files\PostgreSQL. Is PostgreSQL installed?' }

New-Item -ItemType Directory -Force $OutDir | Out-Null
$file = Join-Path $OutDir ("it_hams_v2_" + (Get-Date -Format 'yyyy-MM-dd') + '.dump')
$env:PGPASSWORD = $cfg['DB_PASS']
# Login sessions are left out so nobody inherits your signed-in session.
& $pgDump.FullName -h $cfg['DB_HOST'] -p $cfg['DB_PORT'] -U $cfg['DB_USER'] -d $cfg['DB_NAME'] -Fc --no-owner --no-privileges `
  --exclude-table-data=sessions --exclude-table-data=user_sessions --exclude-table-data=password_reset_tokens -f $file
Remove-Item Env:PGPASSWORD
if ($LASTEXITCODE -ne 0) { throw "pg_dump failed (exit $LASTEXITCODE)" }
"Database copy written to: $file ({0:N1} MB)" -f ((Get-Item $file).Length / 1MB)
