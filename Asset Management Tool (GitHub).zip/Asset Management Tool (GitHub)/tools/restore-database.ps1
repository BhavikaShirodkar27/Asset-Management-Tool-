# Load the shared IT-AMS database copy (.dump) into your local PostgreSQL, using the settings in .env.
# Usage (from the project folder):  powershell -ExecutionPolicy Bypass -File tools\restore-database.ps1 -DumpFile "C:\path\it_hams_v2_YYYY-MM-DD.dump"
# Re-running it replaces your local copy with the dump (asks first).
param([Parameter(Mandatory = $true)][string]$DumpFile)

$ErrorActionPreference = 'Stop'
$DumpFile = $DumpFile.Trim().Trim('"').Trim("'")   # "Copy as path" adds quotes
if (-not (Test-Path $DumpFile)) { throw "File not found: $DumpFile" }
$envFile = Join-Path (Split-Path $PSScriptRoot -Parent) '.env'
if (-not (Test-Path $envFile)) { throw '.env not found. Copy .env.example to .env and fill in your PostgreSQL user/password first.' }
$cfg = @{}
Get-Content $envFile | Where-Object { $_ -match '^\s*([A-Z_]+)\s*=\s*(.*)$' } | ForEach-Object { $cfg[$Matches[1]] = $Matches[2].Trim() }

$bin = Get-ChildItem 'C:\Program Files\PostgreSQL\*\bin\pg_restore.exe' -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1
if (-not $bin) { throw 'pg_restore.exe not found under C:\Program Files\PostgreSQL. Install PostgreSQL first.' }
$psql = Join-Path $bin.DirectoryName 'psql.exe'
$db = $cfg['DB_NAME']
$conn = @('-h', $cfg['DB_HOST'], '-p', $cfg['DB_PORT'], '-U', $cfg['DB_USER'])
$env:PGPASSWORD = $cfg['DB_PASS']
try {
  $exists = & $psql @conn -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname = '$db'"
  if ($LASTEXITCODE -ne 0) { throw "Could not connect to PostgreSQL as $($cfg['DB_USER']). Check DB_USER / DB_PASS in .env." }
  if ($exists -eq '1') {
    $answer = Read-Host "Database '$db' already exists. Replace it with the dump? (yes/no)"
    if ($answer -ne 'yes') { 'Cancelled - nothing changed.'; return }
    & $psql @conn -d postgres -c "DROP DATABASE `"$db`" WITH (FORCE)" | Out-Null
  }
  & $psql @conn -d postgres -c "CREATE DATABASE `"$db`"" | Out-Null
  if ($LASTEXITCODE -ne 0) { throw "Could not create database $db" }
  & $bin.FullName @conn -d $db --no-owner --no-privileges $DumpFile
  if ($LASTEXITCODE -ne 0) { throw "pg_restore reported errors (exit $LASTEXITCODE). See messages above." }
  "Database '$db' restored. Next: npm install, then press F5 in VS Code."
} finally { Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue }
