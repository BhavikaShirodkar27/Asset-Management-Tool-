# IT-AMS — Team Setup (Windows + VS Code, no typing commands)

Do these steps once. Afterwards you only press **F5** in VS Code to run the app.

You get two things:
- **The code**: from GitHub (this repository).
- **The database copy** (`it_hams_v2_YYYY-MM-DD.dump`): shared privately on OneDrive or Teams. It contains company data, so it is never on GitHub.

## 1. Install the tools (one time, default options)
- **Node.js** (LTS): https://nodejs.org
- **PostgreSQL**: https://www.postgresql.org/download/windows/. Write down the password you set for `postgres`.
- **Git**: https://git-scm.com
- **VS Code**: https://code.visualstudio.com

Restart the PC after installing.

## 2. Get the code
1. Open VS Code and click **Source Control** in the left bar (or press Ctrl+Shift+G).
2. Click **Clone Repository**, then **Clone from GitHub**. Sign in to GitHub when asked.
3. Pick the **IT-AMS** repository and choose a folder.
4. Click **Open** when VS Code asks.

## 3. Create your settings file (`.env`)
1. In the VS Code file list, right-click **.env.example** and choose **Copy**.
2. Right-click an empty area of the file list and choose **Paste**.
3. Rename the copy to exactly `.env`.
4. Open `.env` and change these lines, then save with Ctrl+S:
   - `DB_USER=postgres`
   - `DB_PASS=` the PostgreSQL password from step 1
   - `SESSION_SECRET=` any long random text

## 4. Install and load the data (VS Code menu: Terminal → Run Task…)
1. Run **1. Install dependencies** and wait until it finishes.
2. Run **2. Load shared database (.dump file)**. When asked, paste the path of the `.dump` file and press Enter.
   - To get the path: in File Explorer, hold **Shift**, right-click the file, and choose **Copy as path**.
   - Loading takes about a minute.
3. Run **3. Update database tables**.

## 5. Run the app
Press **F5**. The browser opens at http://localhost:3001.

Log in with the admin email and password shared by the project owner. To stop the app, press **Shift+F5**.

## Getting updates later
- **New code:** Source Control → **…** menu → **Pull**. Then run the tasks **1. Install dependencies** and **3. Update database tables**, and press F5.
- **New data:** get the newer `.dump` file and run task **2. Load shared database** again. Type `yes` when it asks to replace your copy.

Each person has their own copy. Changes you make in your app are not seen by others.

## Problems?
| Message | Fix |
|---|---|
| `Could not connect to PostgreSQL` | Check `DB_USER` / `DB_PASS` in `.env` |
| `pg_restore.exe not found` | Reinstall PostgreSQL with the default folder |
| `port 3001 already in use` | The app is already running. Press Shift+F5 first |
| Page has no styling | Run task **Build CSS**, then refresh the browser |

## For the project owner: sending newer data
Go to **Terminal → Run Task… → Make database copy for team (owner only)**. The new file is saved in `Downloads\IT-AMS-team-share`. Share it on OneDrive or Teams.
