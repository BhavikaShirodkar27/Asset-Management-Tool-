-- Intune device inventory snapshot (Intune > Devices > Export, "DevicesWithInventory").
-- Each import replaces the snapshot; used for the dashboard Device Compliance section.
CREATE TABLE IF NOT EXISTS intune_devices (
  id SERIAL PRIMARY KEY,
  device_id VARCHAR(64) NOT NULL UNIQUE,
  device_name VARCHAR(255),
  serial_number VARCHAR(255),
  manufacturer VARCHAR(255),
  model VARCHAR(255),
  os VARCHAR(100),
  platform VARCHAR(30),
  os_version VARCHAR(100),
  compliance VARCHAR(50),
  managed_by VARCHAR(50),
  ownership VARCHAR(50),
  device_state VARCHAR(50),
  join_type VARCHAR(50),
  encrypted BOOLEAN,
  enrollment_date TIMESTAMPTZ,
  last_check_in TIMESTAMPTZ,
  primary_user_upn VARCHAR(255),
  primary_user_email VARCHAR(255),
  primary_user_name VARCHAR(255),
  total_storage_mb BIGINT,
  free_storage_mb BIGINT,
  asset_id INT REFERENCES assets(id) ON DELETE SET NULL,
  data JSONB,
  imported_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_intune_devices_compliance ON intune_devices (compliance);
CREATE INDEX IF NOT EXISTS idx_intune_devices_platform ON intune_devices (platform);
CREATE INDEX IF NOT EXISTS idx_intune_devices_serial ON intune_devices (UPPER(serial_number));
CREATE INDEX IF NOT EXISTS idx_intune_devices_last_check_in ON intune_devices (last_check_in);
CREATE INDEX IF NOT EXISTS idx_assets_serial_upper ON assets (UPPER(serial_number));

CREATE TABLE IF NOT EXISTS intune_imports (
  id SERIAL PRIMARY KEY,
  file_name VARCHAR(255),
  rows_imported INT NOT NULL DEFAULT 0,
  matched_assets INT NOT NULL DEFAULT 0,
  imported_by INT REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
